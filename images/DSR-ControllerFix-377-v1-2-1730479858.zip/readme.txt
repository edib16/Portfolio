DSR CONTROLLER FIX v1.2

DESCRIPTION
-------------
This mod aims to fix the issue of the game no longer reacting to controller input, f.e. if the user alt-tabs out of the game or activates Game Bar.


HOW TO INSTALL/DELETE
-------------
If you don't already use a mod with a dinput8.dll, just drop the dinput8.dll and controllerfix.ini into the game folder.
But if you already have a dinput8.dll there, rename the one coming with this mod to something else and try to chainload it through the other mod.
You can also chainload another mod with the controller fix by entering its filename in the controllerfix.ini between the quotation marks next to dinput8DllWrapper.

To delete the mod, just rename or delete the dll.

CHANGELOG
-------------
1.2 - support for game v1.03.1
1.1 - changed approach to be more ban-safe